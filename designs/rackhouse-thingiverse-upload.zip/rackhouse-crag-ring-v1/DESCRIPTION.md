# Crag Ring: gear ring with carry handle

A light 7 mm gear ring with 11 fully enclosed windows and a hand-size carry handle. Rack your cams, carry it to the crag like a bag, then clip the handle to a sling or a tree.

- **Every opening is fully enclosed.** Once a carabiner's gate closes through it, it can't slide off in any direction: on a wall, in a car, in a pack or at the crag.
- **11 clip openings**, each at least 14 mm wide, with a 6-6 mm strip a carabiner gate closes around.
- **Hangs from:** hand-carry handle (76 x 26 mm opening); also clips to a sling or hook.
- **RACKHOUSE / NOT FOR CLIMBING** debossed into the face.

Size: 152 x 190 mm, 7 mm thick. About 72 g.

## Printing
Prints **flat, text up**, exactly as exported, **no supports**. Fits a 210 mm bed (Ender 3, Prusa MK3/MK4, Bambu A1/P1/X1).
0.2 mm layers, **4 walls, 30% gyroid**. PLA+ indoors, PETG if it lives in a hot car.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
