Title: Rock Ring V3 - Full Trad Rack & Helmet Gear Ring (Rackhouse)
Category: Hobby > Sport & Outdoors
Tags: climbing, trad, rack, gear ring, gear organizer, cam rack, helmet holder, wall hanger, garage organization, rackhouse
License: Creative Commons - Attribution - Non-Commercial - Share Alike
Remix: NO (original design, do not mark as a remix)

---

# Rock Ring V3: full-rack gear ring

Your whole trad rack and your helmet on one ring on the wall.

- **Clip on like a gear sling:** carabiners clip straight onto the ring band.
- **15 numbered notches** on the inner edge keep every cam in size order instead of sliding to the bottom. Enough for a double rack plus nuts and a couple of draws.
- **Helmet hook** in the middle: hang your helmet by its chin strap (13 mm throat).
- **Keyhole** for one #8 pan-head screw, and **3 standoff feet** that hold it 26 mm off the wall so every carabiner clips on easily.
- **RACKHOUSE / NOT FOR CLIMBING** debossed on the band.

Size: 184 x 206 mm, 26 mm deep. About 110-140 g. Built for up to 8 kg of gear.

## Printing
Prints **face down** exactly as exported, feet up, **no supports**. Needs 210 mm of bed in one direction (Ender 3, Prusa MK3/MK4, Bambu A1/P1/X1).
0.2 mm layers, **4 walls, 40% gyroid** (it carries a full rack). PLA+ indoors, PETG in a hot van.

## Hanging
Drive a #8 pan-head screw into a stud or a rated anchor, leaving the head about 9 mm out. Slip the keyhole over it and let the ring drop.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
