Title: Rock Ring V2 - Portable Edge Lift Block for Finger Training (Rackhouse)
Category: Hobby > Sport & Outdoors
Tags: climbing, hangboard, fingerboard, lift block, edge block, grip training, finger strength, bouldering, training, rackhouse
License: Creative Commons - Attribution - Non-Commercial - Share Alike
Remix: NO (original design, do not mark as a remix)

---

# Rock Ring V2: portable edge lift block

Hangboard-style finger training without a hangboard. Run a cord through the channel, hang a kettlebell or loaded bag, and lift it off the floor by the edge.

- **19 mm edge** on one side, **11 mm edge** on the other. Flip it to change difficulty.
- 3 mm radiused edges for skin-friendly crimps.
- **14 mm load channel** with 45-degree countersunk ends so the cord doesn't chafe.
- 100 x 56 x 58 mm, about 90-120 g. Fits in a chalk bucket.

## Printing
Prints **standing on its end** exactly as exported, **no supports**. Every layer contains the whole T profile, so finger loads pull along the layers instead of peeling them apart.
0.2 mm layers, **4 walls, 30% gyroid** minimum. PLA+ or PETG.

## Safety
Keep the weight low to the floor. Use cord or a loading pin rated well above your load. Inspect the block before every session and retire it if you see cracks or layer separation. Never hang body weight from it. Warm up and add load gradually: finger pulleys strain easily.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
