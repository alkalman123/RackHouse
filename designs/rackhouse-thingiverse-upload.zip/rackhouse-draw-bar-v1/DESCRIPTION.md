Title: Draw Bar - Quickdraw & Extra Gear Wall Rail (Rackhouse)
Category: Hobby > Sport & Outdoors
Tags: climbing, quickdraw, quickdraw holder, gear rail, gear organizer, sling, wall rack, garage organization, rackhouse
License: Creative Commons - Attribution - Non-Commercial - Share Alike
Remix: NO (original design, do not mark as a remix)

---

# Draw Bar: quickdraw & extra-gear rail

A straight wall rail for your quickdraws, slings, nuts and everything that doesn't fit on your main rack.

- **7 slots** (13 x 22 mm, 22 mm apart): clip a carabiner through a slot and around the 11 mm bottom rail.
- **Two keyholes** for #8 pan-head screws, 176 mm apart.
- **12 mm standoff ends** hold it 20 mm off the wall so carabiners clip on cleanly.
- **RACKHOUSE / NOT FOR CLIMBING** debossed along the top.

Size: 200 x 44 mm, 20 mm deep. About 55-65 g. Built for up to 5 kg of gear.

## Printing
Prints **face down** exactly as exported, standoffs up, **no supports**. 0.2 mm layers, 4 walls, 30% gyroid.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
