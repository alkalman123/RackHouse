# Double Ring: two-row gear ring for cams & draws

A two-row gear ring with 20 fully enclosed windows: 13 around the outside for cams and 7 on the inner row for quickdraws, nuts and a nut tool.

- **Every opening is fully enclosed.** Once a carabiner's gate closes through it, it can't slide off in any direction: on a wall, in a car, in a pack or at the crag.
- **20 clip openings**, each at least 14 mm wide, with a 6-7.9 mm strip a carabiner gate closes around.
- **Hangs from:** top eye: hook, carabiner or sling.
- **RACKHOUSE / NOT FOR CLIMBING** debossed into the face.

Size: 180 x 207 mm, 9 mm thick. About 122 g.

## Printing
Prints **flat, text up**, exactly as exported, **no supports**. Fits a 210 mm bed (Ender 3, Prusa MK3/MK4, Bambu A1/P1/X1).
0.2 mm layers, **4 walls, 30% gyroid**. PLA+ indoors, PETG if it lives in a hot car.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
