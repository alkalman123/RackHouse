# Pocket Bar: 4-slot carabiner bar

A 130 mm bar with 4 enclosed slots for a pack lid, glovebox or crag bag: a nut tool, a couple of draws, a belay device and a locker.

- **Every opening is fully enclosed.** Once a carabiner's gate closes through it, it can't slide off in any direction: on a wall, in a car, in a pack or at the crag.
- **4 clip openings**, each at least 14 mm wide, with a 9-9 mm strip a carabiner gate closes around.
- **Hangs from:** end slots: two hooks, two screws with washers, or a sling through both.
- **RACKHOUSE / NOT FOR CLIMBING** debossed into the face.

Size: 130 x 44 mm, 9 mm thick. About 33 g.

## Printing
Prints **flat, text up**, exactly as exported, **no supports**. Fits a 210 mm bed (Ender 3, Prusa MK3/MK4, Bambu A1/P1/X1).
0.2 mm layers, **4 walls, 30% gyroid**. PLA+ indoors, PETG if it lives in a hot car.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
