Title: Cup Cradle V2 - Wide-Mouth Nalgene Car Cupholder Adapter (Rackhouse)
Category: Hobby > Automotive
Tags: nalgene, water bottle, cupholder, cup holder adapter, car, automotive, wide mouth, 32 oz, hiking, climbing, rackhouse
License: Creative Commons - Attribution - Non-Commercial - Share Alike
Remix: NO (original design, do not mark as a remix)

---

# Cup Cradle V2: wide-mouth bottle cupholder adapter

A 32 oz wide-mouth water bottle is too fat for a car cupholder. This holds it upright.

- **Tapered stem with 8 flex ribs** wedges into round cupholders from **69 to 79 mm** across.
- **45-degree flare** into a **94 mm** cup, 51 mm deep: fits 32 oz wide-mouth bottles (about 3.5 in / 89 mm across).
- **Windows** around the cup so you can pinch the bottle out, and a **drain hole** for condensation.
- 101 mm wide, 135 mm tall. About 140-180 g.

Measure your cupholder before printing. Shallow, square or stepped cupholders may not seat the same way.

## Printing
Prints **stem down** exactly as exported, **no supports** (every overhang is 45 degrees or steeper).
0.2 mm layers, 3 walls (4 for a tighter fit), 15-20% gyroid. **Use PETG** if it'll sit in a hot car: PLA softens around 55-60 C.

Nalgene is a trademark of its owner. This adapter is not affiliated with or endorsed by Nalgene.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
