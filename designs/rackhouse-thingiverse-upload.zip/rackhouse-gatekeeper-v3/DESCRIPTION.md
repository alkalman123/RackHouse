Title: Gatekeeper V3 - Trad Rack & Helmet Wall Hanger (Rackhouse)
Category: Hobby > Sport & Outdoors
Tags: climbing, trad, rack, gear organizer, helmet holder, cam, quickdraw, wall hanger, garage organization, van life, rackhouse
License: Creative Commons - Attribution - Non-Commercial - Share Alike
Remix: NO (original design, do not mark as a remix)

---

# Gatekeeper V3: trad rack & helmet hanger

Hang your whole trad rack and your helmet off one hook in the garage, van or gear closet.

- **4 gear slots** (20 x 11 mm) sized for a carabiner gate: clip cams and quickdraws.
- **Big pear-shaped opening**: drape slings, cordelettes or a rope coil.
- **J-hook** at the bottom: drop your helmet's chin strap in without unbuckling it. The gate is angled so the strap stays put.
- **13 mm hang hole** in the top tab: one hook, peg or screw.
- **RACKHOUSE / NOT FOR CLIMBING** debossed into the rail.

Size: 209 x 104 x 10 mm. About 65-85 g.

## Printing
Prints flat exactly as exported, **no supports**. Needs a bed of at least 210 mm in one direction (Ender 3, Prusa MK3/MK4, Bambu A1/P1/X1).
0.2 mm layers, 4 walls, 30% gyroid. PLA+ indoors, PETG in a hot van.

Use a screw into a stud or a rated anchor once it's loaded with a full rack.

**License:** Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0). Print and remix it for yourself. Please don't sell prints or files. Commercial rights are reserved by Rackhouse Supply Co.; contact rackhousesupplyco@gmail.com for a commercial license.

**Not climbing equipment.** Never use this part in a climbing, rescue or fall-protection system.

Don't have a printer? Buy one printed to order in six colors at https://alkalman123.github.io/RackHouse/
